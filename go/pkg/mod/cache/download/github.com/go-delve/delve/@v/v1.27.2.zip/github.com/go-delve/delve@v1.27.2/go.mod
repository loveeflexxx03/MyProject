module github.com/go-delve/delve

go 1.25.0

require (
	github.com/cilium/ebpf v0.22.0
	github.com/cosiner/argv v0.1.0
	github.com/creack/pty v1.1.20
	github.com/derekparker/trie/v3 v3.2.0
	github.com/go-delve/liner v1.2.3-0.20231231155935-4726ab1d7f62
	github.com/google/go-dap v0.12.0
	github.com/mattn/go-colorable v0.1.13
	github.com/mattn/go-isatty v0.0.20
	github.com/spf13/cobra v1.10.2
	github.com/spf13/pflag v1.0.10
	go.starlark.net v0.0.0-20231101134539-556fd59b42f6
	go.yaml.in/yaml/v3 v3.0.4
	golang.org/x/arch v0.28.0
	golang.org/x/sys v0.46.0
	golang.org/x/telemetry v0.0.0-20241106142447-58a1122356f5
	golang.org/x/text v0.40.0
)

require (
	github.com/cpuguy83/go-md2man/v2 v2.0.6 // indirect
	github.com/inconshreveable/mousetrap v1.1.0 // indirect
	github.com/mattn/go-runewidth v0.0.13 // indirect
	github.com/rivo/uniseg v0.2.0 // indirect
	github.com/russross/blackfriday/v2 v2.1.0 // indirect
	golang.org/x/sync v0.22.0 // indirect
)
