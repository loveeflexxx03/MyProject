// Copyright 2026 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// This file exposes yet-unpublished analyzers to the tests.

package modernize

var (
	ImportCommentAnalyzer     = importCommentAnalyzer
	ReflectTypeAssertAnalyzer = reflectTypeAssertAnalyzer
	SlicesBackwardAnalyzer    = slicesBackwardAnalyzer
	SlicesClipAnalyzer        = slicesClipAnalyzer
	UnsafeFuncsAnalyzer       = unsafeFuncsAnalyzer
)
